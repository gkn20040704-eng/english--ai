# 📚 智能AI学习英语

一个基于 DeepSeek AI 的英语学习工具，纯前端单页面应用。

## ✨ 功能

- **📝 句子管理** — 自定义添加英文句子、中文翻译和难度等级，支持增删改查
- **🤖 AI 句子分析** — DeepSeek AI 分析句子成分（主谓宾定状补）、时态语态、句子结构、易错点
- **🔊 发音练习** — 浏览器语音合成，支持 🇺🇸 美式发音 / 🇬🇧 英式发音
- **📚 场景例句** — 输入单词，AI 根据考试/生活/商务/旅游等不同场景生成贴合例句
- **📝 考核模式** — 从句子库随机出题，AI 智能评判翻译是否准确（意思相近即可）

## 🚀 使用方式

1. 下载或克隆本项目
2. 在 `index.html` 第 316 行填入你的 DeepSeek API Key：
   ```javascript
   const HARDCODED_API_KEY = 'sk-你的key';
   ```
3. 浏览器打开 `index.html` 即可使用

> 获取 API Key：[platform.deepseek.com](https://platform.deepseek.com)

## 🛠 技术栈

- HTML + CSS + JavaScript
- DeepSeek Chat API
- Web Speech API（浏览器语音合成）
- localStorage 数据持久化

## 📁 项目结构

```
smart-english/
└── index.html    # 全部代码，开箱即用
```
